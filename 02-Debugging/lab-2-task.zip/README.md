# io-2021
## Laboratoria 2
### Zadanie
Waszym zadaniem jest:
1. Odnalezienie oraz poprawienie posianych błędów w programie
przeszukującym wszerz podany graf. Przeszukiwanie zaczyna się od
wierzchołka o najniższym numerze spośród dotychczas nieodwiedzonych.
2. Uporządkowanie, uzupełnienie i wygenerowanie dokumentacji do projektu

1: Błędy:
- błędne czytanie plików wejściowych.
- kolejkowanie w procesorze BFS.
- Sprawdzaniu czy kolejne wierzchołki grafu są odwiedzone było odwrócone.

2: Uzupełnione docsy w kodzie wraz javadockiem w folderze javadoc
